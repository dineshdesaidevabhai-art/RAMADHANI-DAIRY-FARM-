import React from 'react'

function App() {
  return (
    <div>
      <h1>React + Vite App</h1>
      <p>Welcome to your application!</p>
    </div>
  )
}

export default App
