import {makeCustomerToken} from "./backend.js";
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const total=c=>c.entries.reduce((s,e)=>s+Number(e.litres||0),0);
export function openWhatsAppBill(c){
 const base=import.meta.env.VITE_PUBLIC_BASE_URL
   ? import.meta.env.VITE_PUBLIC_BASE_URL.replace(/\/$/, "")
   : new URL("./", window.location.href).toString().replace(/\/$/, "");
 const link=base+"/#/customer/"+makeCustomerToken(c);
 const litres=total(c), totalBill=litres*c.rate, remaining=Math.max(0,totalBill-c.advance);
 const msg=`રામાધણી ડેરી ફાર્મ%0A%0Aગ્રાહક: ${c.name}%0Aમહિનાનું કુલ દૂધ: ${litres.toFixed(1)} લીટર%0Aપ્રતિ લીટર ભાવ: ${money(c.rate)}%0Aકુલ બિલ: ${money(totalBill)}%0AAdvance: ${money(c.advance)}%0ARemaining: ${money(remaining)}%0A%0Aતમારો વ્યક્તિગત લેજર:%0A${link}%0A%0Aઆભાર — રામાધણી ડેરી ફાર્મ`;
 window.open(`https://wa.me/${c.mobile}?text=${msg}`,"_blank");
}