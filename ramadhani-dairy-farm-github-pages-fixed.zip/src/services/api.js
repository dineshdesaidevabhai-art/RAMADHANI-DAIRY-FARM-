// Production integration boundary.
// Keep private API calls on your server. Frontend must only receive authorized data.
export async function api(path, options={}) {
  const res = await fetch(path, {
    ...options,
    headers: {"Content-Type":"application/json", ...(options.headers||{})}
  });
  if(!res.ok) throw new Error("API request failed");
  return res.json();
}

// Suggested server endpoints:
// /api/owner/*
// /api/customer/ledger/:token
// /api/ai/chat
// /api/whatsapp/monthly-bill
