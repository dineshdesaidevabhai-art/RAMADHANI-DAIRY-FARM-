// Demo token layer. Production: issue opaque random tokens server-side,
// store only a secure hash in DB, validate token server-side, add expiry/revocation.
export function makeCustomerToken(customer){
  const raw = btoa(unescape(encodeURIComponent("rdf:"+customer.id+":"+customer.mobile)));
  return raw.replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_");
}
export function getCustomerByToken(token, customers){
  try{
    const decoded=decodeURIComponent(escape(atob(token.replace(/-/g,"+").replace(/_/g,"/"))));
    const id=decoded.split(":")[1];
    return customers.find(c=>c.id===id) || null;
  }catch{return null}
}

// Production API boundary:
// export async function fetchPrivateLedger(token){ return fetch(`/api/customer/ledger/${token}`) }
// Never trust client-provided customer_id or expose service-role credentials.
