import React, {useEffect, useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";
import {getCustomerByToken, makeCustomerToken} from "./services/backend.js";
import {openWhatsAppBill} from "./services/whatsapp.js";

const seed = [
  {id:"c1",name:"જયંતીભાઈ",mobile:"9876543210",address:"થરાદ",morning:2,evening:2,rate:70,advance:500,
   entries:[
    {date:"2026-09-01",session:"સવાર",litres:2},{date:"2026-09-01",session:"સાંજ",litres:2},
    {date:"2026-09-02",session:"સવાર",litres:2},{date:"2026-09-02",session:"સાંજ",litres:2},
    {date:"2026-09-03",session:"સવાર",litres:1.5},{date:"2026-09-03",session:"સાંજ",litres:2}
   ]},
  {id:"c2",name:"રમેશભાઈ",mobile:"9999999999",address:"વાવ",morning:3,evening:2,rate:68,advance:0,entries:[]}
];

function money(n){return "₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2})}
function monthTotal(c){return c.entries.reduce((s,e)=>s+Number(e.litres||0),0)}
function bill(c){return monthTotal(c)*Number(c.rate||0)}
function remaining(c){return Math.max(0,bill(c)-Number(c.advance||0))}
function load(){try{return JSON.parse(localStorage.getItem("rdf_customers"))||seed}catch{return seed}}
function save(x){localStorage.setItem("rdf_customers",JSON.stringify(x))}

function App(){
 const [customers,setCustomers]=useState(load());
 const [route,setRoute]=useState(location.hash);
 const [tab,setTab]=useState("ડેશબોર્ડ");
 const [selected,setSelected]=useState(null);
 const [notice,setNotice]=useState("");
 useEffect(()=>{const f=()=>setRoute(location.hash);addEventListener("hashchange",f);return()=>removeEventListener("hashchange",f)},[]);
 const token=route.startsWith("#/customer/")?route.split("/")[2]:null;
 const privateCustomer=token?getCustomerByToken(token,customers):null;

 const refresh=(x)=>{setCustomers(x);save(x)}
 if(token){
   return <CustomerPage customer={privateCustomer} onHome={()=>location.hash=""}/>;
 }
 return <OwnerApp customers={customers} setCustomers={refresh} tab={tab} setTab={setTab}
   selected={selected} setSelected={setSelected} notice={notice} setNotice={setNotice}/>;
}

function Header({tab,setTab}){
 return <header className="top"><div className="brand"><div className="buffalo">🐃</div><div><b>રામાધણી ડેરી ફાર્મ</b><small>દૂધ વ્યવસ્થાપન સિસ્ટમ</small></div></div>
 <nav>{["ડેશબોર્ડ","ગ્રાહકો","દૈનિક એન્ટ્રી","લેજર","ચુકવણી","સેટિંગ્સ"].map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}</button>)}</nav>
 <div className="owner">👤 માલિક<br/><strong>મુકેશ રબારી</strong></div></header>
}

function OwnerApp(p){
 return <div className="app"><Header {...p}/><main>
 {p.tab==="ડેશબોર્ડ"&&<Dashboard customers={p.customers}/>}
 {p.tab==="ગ્રાહકો"&&<Customers {...p}/>}
 {p.tab==="દૈનિક એન્ટ્રી"&&<Daily customers={p.customers} setCustomers={p.setCustomers}/>}
 {p.tab==="લેજર"&&<Ledger customers={p.customers}/>}
 {p.tab==="ચુકવણી"&&<Payments customers={p.customers} setCustomers={p.setCustomers}/>}
 {p.tab==="સેટિંગ્સ"&&<Settings/>}
 </main><footer>© 2026 રામાધણી ડેરી ફાર્મ · Owner-only management</footer></div>
}

function Dashboard({customers}){
 const litres=customers.reduce((s,c)=>s+monthTotal(c),0), total=customers.reduce((s,c)=>s+bill(c),0), pending=customers.reduce((s,c)=>s+remaining(c),0);
 return <><div className="hero"><div><span className="eyebrow">OWNER DASHBOARD</span><h1>આજનું ડેરી મેનેજમેન્ટ</h1><p>ગ્રાહકો, દૂધ, બિલ અને લેજર એક જ જગ્યાએ.</p></div><div className="date">{new Date().toLocaleDateString("gu-IN",{dateStyle:"full"})}</div></div>
 <section className="cards"><Stat t="કુલ ગ્રાહકો" v={customers.length}/><Stat t="માસિક દૂધ" v={litres.toFixed(1)+" L"}/><Stat t="માસિક બિલ" v={money(total)}/><Stat t="બાકી રકમ" v={money(pending)}/></section>
 <section className="panel"><h2>ઝડપી ગ્રાહક સારાંશ</h2><table><thead><tr><th>ગ્રાહક</th><th>દૂધ</th><th>ભાવ</th><th>બિલ</th><th>બાકી</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.name}</td><td>{monthTotal(c).toFixed(1)} L</td><td>{money(c.rate)}/L</td><td>{money(bill(c))}</td><td>{money(remaining(c))}</td></tr>)}</tbody></table></section></>
}
function Stat({t,v}){return <div className="stat"><span>{t}</span><strong>{v}</strong></div>}

function Customers({customers,setCustomers,setSelected}){
 const [form,setForm]=useState({name:"",mobile:"",address:"",morning:"",evening:"",rate:"70",advance:"0"});
 const [edit,setEdit]=useState(null);
 const submit=e=>{e.preventDefault(); if(!form.name||!form.mobile)return;
   if(edit){setCustomers(customers.map(c=>c.id===edit?{...c,...form,morning:+form.morning,evening:+form.evening,rate:+form.rate,advance:+form.advance}:c))}
   else setCustomers([...customers,{...form,id:"c"+Date.now(),morning:+form.morning,evening:+form.evening,rate:+form.rate,advance:+form.advance,entries:[]}]);
   setForm({name:"",mobile:"",address:"",morning:"",evening:"",rate:"70",advance:"0"});setEdit(null)
 };
 const del=id=>{if(confirm("ગ્રાહક ડિલીટ કરવો છે?"))setCustomers(customers.filter(c=>c.id!==id))}
 const editC=c=>{setEdit(c.id);setForm({name:c.name,mobile:c.mobile,address:c.address,morning:c.morning,evening:c.evening,rate:c.rate,advance:c.advance})}
 return <><div className="sectionTitle"><div><span className="eyebrow">CUSTOMERS</span><h1>ગ્રાહક વ્યવસ્થાપન</h1></div></div>
 <div className="grid2"><form className="panel form" onSubmit={submit}><h2>{edit?"ગ્રાહક સંપાદિત કરો":"નવો ગ્રાહક ઉમેરો"}</h2>
 {["name","mobile","address","morning","evening","rate","advance"].map((k,i)=><label key={k}>{["નામ","મોબાઇલ નંબર","સરનામું","સવારનું દૂધ (L)","સાંજનું દૂધ (L)","પ્રતિ લીટર ભાવ","Advance"][i]}<input value={form[k]} type={["morning","evening","rate","advance"].includes(k)?"number":"text"} onChange={e=>setForm({...form,[k]:e.target.value})} required={k!=="address"}/></label>)}
 <button className="primary">{edit?"સાચવો":"ગ્રાહક ઉમેરો"}</button></form>
 <div className="panel"><h2>ગ્રાહક યાદી</h2>{customers.map(c=><div className="customerRow" key={c.id}><div><b>{c.name}</b><small>{c.mobile} · {c.address}</small></div><div className="rowBtns"><button onClick={()=>editC(c)}>સંપાદિત</button><button onClick={()=>del(c.id)}>ડિલીટ</button><button onClick={()=>location.hash="/customer/"+makeCustomerToken(c)}>લેજર</button></div></div>)}</div></div></>
}

function Daily({customers,setCustomers}){
 const [date,setDate]=useState(new Date().toISOString().slice(0,10)); const [session,setSession]=useState("સવાર"); const [vals,setVals]=useState({});
 const saveAll=()=>{setCustomers(customers.map(c=>{const v=vals[c.id];if(v===undefined)return c;const old=c.entries.filter(e=>!(e.date===date&&e.session===session));return {...c,entries:[...old,{date,session,litres:Number(v||0)}]}}));setVals({});alert("દૂધ એન્ટ્રી સાચવાઈ ગઈ.")};
 return <><div className="sectionTitle"><div><span className="eyebrow">DAILY ENTRY</span><h1>દૈનિક દૂધ એન્ટ્રી</h1></div><div className="filters"><input type="date" value={date} onChange={e=>setDate(e.target.value)}/><select value={session} onChange={e=>setSession(e.target.value)}><option>સવાર</option><option>સાંજ</option></select></div></div>
 <div className="panel"><table><thead><tr><th>ગ્રાહક</th><th>નક્કી દૂધ</th><th>આજનું દૂધ (L)</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.name}</td><td>{session==="સવાર"?c.morning:c.evening} L</td><td><input className="smallInput" type="number" step=".1" value={vals[c.id]??(session==="સવાર"?c.morning:c.evening)} onChange={e=>setVals({...vals,[c.id]:e.target.value})}/></td></tr>)}</tbody></table><button className="primary" onClick={saveAll}>બધી એન્ટ્રી સાચવો</button></div></>
}

function Ledger({customers}){
 const [id,setId]=useState(customers[0]?.id||""); const c=customers.find(x=>x.id===id);
 if(!c)return <div className="empty">હજુ કોઈ ગ્રાહક નથી.</div>;
 return <><div className="sectionTitle"><div><span className="eyebrow">LEDGER</span><h1>ગ્રાહક લેજર</h1></div><select value={id} onChange={e=>setId(e.target.value)}>{customers.map(x=><option value={x.id} key={x.id}>{x.name}</option>)}</select></div>
 <div className="cards"><Stat t="કુલ દૂધ" v={monthTotal(c).toFixed(1)+" L"}/><Stat t="કુલ બિલ" v={money(bill(c))}/><Stat t="Advance" v={money(c.advance)}/><Stat t="Remaining" v={money(remaining(c))}/></div>
 <div className="panel"><h2>{c.name} — તારીખ પ્રમાણે લેજર</h2><table><thead><tr><th>તારીખ</th><th>સમય</th><th>દૂધ</th><th>રકમ</th></tr></thead><tbody>{c.entries.map((e,i)=><tr key={i}><td>{e.date}</td><td>{e.session}</td><td>{e.litres} L</td><td>{money(e.litres*c.rate)}</td></tr>)}</tbody></table><button className="whatsapp" onClick={()=>openWhatsAppBill(c)}>WhatsApp પર માસિક બિલ મોકલો</button></div></>
}

function Payments({customers,setCustomers}){
 const [id,setId]=useState(customers[0]?.id||""),[amount,setAmount]=useState("");
 const c=customers.find(x=>x.id===id);
 const add=()=>{if(!c||!amount)return;setCustomers(customers.map(x=>x.id===id?{...x,advance:Number(x.advance)+Number(amount)}:x));setAmount("")};
 return <><div className="sectionTitle"><div><span className="eyebrow">PAYMENTS</span><h1>Advance / Remaining</h1></div></div><div className="grid2"><div className="panel form"><label>ગ્રાહક<select value={id} onChange={e=>setId(e.target.value)}>{customers.map(x=><option value={x.id} key={x.id}>{x.name}</option>)}</select></label><label>Advance / ચુકવણી<input type="number" value={amount} onChange={e=>setAmount(e.target.value)}/></label><button className="primary" onClick={add}>ચુકવણી ઉમેરો</button></div>{c&&<div className="panel"><h2>{c.name}</h2><div className="balance"><span>કુલ બિલ</span><b>{money(bill(c))}</b></div><div className="balance"><span>Advance</span><b>{money(c.advance)}</b></div><div className="balance"><span>Remaining</span><b>{money(remaining(c))}</b></div></div>}</div></>
}

function Settings(){return <><div className="sectionTitle"><div><span className="eyebrow">SETTINGS</span><h1>સેટિંગ્સ</h1></div></div><div className="grid2"><div className="panel"><h2>ડેટાબેઝ</h2><p>Production માટે Firebase અથવા Supabase adapter જોડો.</p><p className="safe">✓ Secret keys frontendમાં રાખવામાં આવતી નથી.</p></div><div className="panel"><h2>Privacy & Security</h2><ul><li>Owner dashboard માત્ર authenticated Owner માટે રાખવો.</li><li>Customer URL random opaque tokenથી સુરક્ષિત છે.</li><li>Productionમાં server-side token validation અને database rules ફરજિયાત છે.</li><li>Token revoke/expire કરી શકાય તેવી backend logic ઉમેરવી.</li></ul></div></div></>}

function CustomerPage({customer,onHome}){
 if(!customer)return <div className="private"><div className="privateCard"><div className="buffalo big">🐃</div><h1>રામાધણી ડેરી ફાર્મ</h1><p>આ લેજર લિંક માન્ય નથી અથવા સમાપ્ત થઈ ગઈ છે.</p><button className="primary" onClick={onHome}>Visit App / Website</button></div></div>;
 const [q,setQ]=useState(""), [messages,setMessages]=useState([{role:"bot",text:"નમસ્તે! હું તમારા દૂધ અને લેજર વિશે મદદ કરી શકું છું. આજે તમે શું જાણવા માંગો છો?"}]);
 const ask=()=>{if(!q.trim())return;let a="તમારા આ મહિનાના કુલ દૂધ "+monthTotal(customer).toFixed(1)+" લીટર છે અને કુલ બિલ "+money(bill(customer))+" છે."; if(q.includes("બાકી")||q.toLowerCase().includes("remaining"))a="તમારી હાલની બાકી રકમ "+money(remaining(customer))+" છે.";setMessages([...messages,{role:"user",text:q},{role:"bot",text:a}]);setQ("")};
 return <div className="customerSite"><div className="customerTop"><div className="buffalo big">🐃</div><div><h1>રામાધણી ડેરી ફાર્મ</h1><p>Owner: મુકેશ રબારી</p></div><button onClick={onHome}>Visit App / Website</button></div>
 <main className="customerMain"><div className="welcome"><span>તમારું વ્યક્તિગત લેજર</span><h2>નમસ્તે, {customer.name} 👋</h2><p>આ પેજ પર માત્ર તમારા પોતાના દૂધ અને બિલની માહિતી છે.</p></div>
 <div className="cards"><Stat t="આ મહિનાનું દૂધ" v={monthTotal(customer).toFixed(1)+" L"}/><Stat t="પ્રતિ લીટર ભાવ" v={money(customer.rate)}/><Stat t="કુલ બિલ" v={money(bill(customer))}/><Stat t="બાકી" v={money(remaining(customer))}/></div>
 <div className="panel"><h2>મારો લેજર</h2><table><thead><tr><th>તારીખ</th><th>સમય</th><th>દૂધ</th><th>રકમ</th></tr></thead><tbody>{customer.entries.map((e,i)=><tr key={i}><td>{e.date}</td><td>{e.session}</td><td>{e.litres} L</td><td>{money(e.litres*customer.rate)}</td></tr>)}</tbody></table></div>
 <div className="panel chatbot"><h2>🤖 ગ્રાહક AI સહાયક</h2><div className="messages">{messages.map((m,i)=><div className={m.role} key={i}>{m.text}</div>)}</div><div className="chatInput"><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ask()} placeholder="દૂધ, બિલ અથવા લેજર વિશે પૂછો..."/><button onClick={ask}>મોકલો</button><button title="Voice-ready">🎙️</button></div><small>AI/Voice production માટે server-side API જોડવાની જગ્યા તૈયાર છે.</small></div></main></div>
}
createRoot(document.getElementById("root")).render(<App/>);