import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  // Relative asset paths make the app work on GitHub Pages project URLs
  // such as https://USERNAME.github.io/REPOSITORY/ without hard-coding a repo name.
  base: "./",
  plugins: [react()]
});
